# chatgpt-custom-instruction-switcher
ChatGPT Custom Instruction Switcher. Extension/Addon for Chrome and Firefox which allows you to create and maintain multiple sets of custom instructions for use with ChatGPT's free web interface, and to switch between them whenever you want.
